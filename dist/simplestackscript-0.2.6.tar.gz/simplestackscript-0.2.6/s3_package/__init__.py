# simplestackscript/s3_package/__init__.py
from .interpreter import Interpreter